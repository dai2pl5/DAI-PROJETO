Use the following files:

(RECOMMENDED)		jquery.nouislider.all.min.js - If you want to use libLink, wNumb and the Pips add-on. Includes noUiSlider.
(ALTERNATIVE)		jquery.nouislider.min.js - noUiSlider without any additions

(REQUIRED)			jquery.nouislider.min.css - Styling (REQUIRED)
(RECOMMENDED)		jquery.nouislider.pips.min.css - If you are using the Pips add-on.
